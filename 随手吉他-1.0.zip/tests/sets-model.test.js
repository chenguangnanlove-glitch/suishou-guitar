import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_STATE} from '../dist/music.js';
import {arrangement,restoreArrangement,saveSet,deleteSet,readSets,sameArrangement} from '../dist/sets-model.js';
const copy=x=>JSON.parse(JSON.stringify(x));
test('saved sets isolate exact custom frets, independent patterns and subsequent edits',()=>{
 const state=copy(DEFAULT_STATE);state.pads[0]={chord:'我的F',nameMode:'manual',frets:[1,3,3,2,1,1],pattern:{...copy(state.pattern),style:'arp',bpm:240}};
 const sets=saveSet([],'a','歌曲 A',state),snapshot=arrangement(state);
 state.pads[0].frets[0]=3;state.pattern.bpm=100;
 assert.deepEqual(sets[0].arrangement,snapshot);
 const restored=restoreArrangement({...state,volume:31,haptics:true},sets[0].arrangement);
 assert.deepEqual(restored.pads,snapshot.pads);assert.equal(restored.pattern.bpm,80);
 assert.equal(restored.volume,31);assert.equal(restored.haptics,true);
 restored.pads[0].frets[0]=9;assert.equal(sets[0].arrangement.pads[0].frets[0],1);
});
test('overwrite and deletion target only the chosen set and leave inputs unchanged',()=>{
 const a=saveSet([],'a','A',DEFAULT_STATE),b=saveSet(a,'b','B',DEFAULT_STATE),c=saveSet(b,'a','A2',DEFAULT_STATE);
 assert.equal(c.length,2);assert.equal(c[0].name,'A2');assert.equal(b[0].name,'A');
 assert.deepEqual(deleteSet(c,'a').map(s=>s.id),['b']);assert.equal(c.length,2);
});
test('damaged entries are rejected, duplicate ids filtered and legacy custom names repaired',()=>{
 const valid=saveSet([],'a','A',DEFAULT_STATE)[0],legacy=copy(valid);legacy.id='b';legacy.arrangement.pads[0]={chord:'C',frets:[1,3,3,2,1,1],pattern:null};
 const results=readSets([valid,valid,{...valid,id:'broken',arrangement:{pads:[]}},legacy,null]);
 assert.deepEqual(results.map(s=>s.id),['a','b']);assert.equal(results[1].arrangement.pads[0].chord,'F');
 assert.throws(()=>restoreArrangement(DEFAULT_STATE,{pads:[]}));assert.throws(()=>saveSet([],'a','  ',DEFAULT_STATE));
});
test('device preferences do not dirty the saved arrangement, musical edits do',()=>{
 const a=copy(DEFAULT_STATE),b={...copy(a),volume:12,haptics:true};assert(sameArrangement(a,b));
 b.pads[0].chord='D';assert(!sameArrangement(a,b));
});

test('retired mute patterns migrate in saved sets and drafts without changing voicings',async()=>{
 const {normalizeLegacyArticulations,labelWidth}=await import('../dist/music.js');
 const legacy=copy(DEFAULT_STATE);legacy.pattern.style='mute';legacy.pads[0]={chord:'晚风',nameMode:'manual',frets:[1,3,3,2,1,1],pattern:{...copy(legacy.pattern)}};
 const next=normalizeLegacyArticulations(legacy);assert.equal(next.pattern.style,'down');assert.equal(next.pads[0].pattern.style,'down');assert.deepEqual(next.pads[0].frets,legacy.pads[0].frets);assert.equal(legacy.pattern.style,'mute');
 const entry=saveSet([],'legacy','旧配置',legacy)[0];assert.equal(readSets([entry])[0].arrangement.pattern.style,'down');assert.equal(restoreArrangement(DEFAULT_STATE,entry.arrangement).pads[0].pattern.style,'down');
 assert.equal(labelWidth('E7'),2);assert.equal(labelWidth('自选和弦'),8);
});
