import test from 'node:test';import assert from 'node:assert/strict';
import {validRiff,putRiffStep} from '../dist/riff-model.js';
import {DEFAULT_STATE,DEFAULT_PATTERN,buildEvents,padVoice,validState} from '../dist/music.js';
import {saveSet,readSets,restoreArrangement} from '../dist/sets-model.js';
import {GuitarAudio} from '../dist/audio.js';
const riff={bpm:160,steps:[{string:6,fret:3},{string:2,fret:1},null,{string:1,fret:12}]};
const pad={kind:'riff',chord:'小过门',riff,pattern:null};
test('Riff events preserve order, exact string/fret pitch, rest timing and note gates',()=>{
 const events=buildEvents(padVoice(pad),DEFAULT_PATTERN);assert.deepEqual(events.map(e=>e.midi),[43,60,76]);assert.deepEqual(events.map(e=>e.string),[6,2,1]);assert.deepEqual(events.map(e=>e.time),[0,.1875,.5625]);assert(events.every(e=>e.gate===.16875));assert.deepEqual(buildEvents(padVoice(pad),{...DEFAULT_PATTERN,style:'up',bpm:45}),events);
});
test('Riff validation rejects empty, all-rest, oversized, invalid frets, strings and speeds',()=>{
 assert(validRiff(riff));for(const r of [{...riff,bpm:59},{...riff,bpm:321},{...riff,steps:[]},{...riff,steps:[null]},{...riff,steps:Array(17).fill({string:1,fret:0})},{...riff,steps:[{string:0,fret:0}]},{...riff,steps:[{string:1,fret:13}]},{...riff,steps:[{string:1,fret:.5}]}])assert.equal(validRiff(r),false);
});
test('append, replace, repeat notes and rests preserve prior draft and enforce 16 steps',()=>{
 let steps=putRiffStep([], -1,{string:1,fret:0});steps=putRiffStep(steps,-1,{string:1,fret:0});assert.equal(steps.length,2);const changed=putRiffStep(steps,0,null);assert.equal(changed[0],null);assert.equal(steps[0].fret,0);assert.equal(changed[1].fret,0);assert.throws(()=>putRiffStep(Array(16).fill(null),-1,null));assert.equal(putRiffStep(Array(16).fill(null),2,{string:2,fret:1}).length,16);
});
test('mixed chord/Riff sets roundtrip and isolate their sequence while old chord state remains valid',()=>{
 const state=structuredClone(DEFAULT_STATE);state.pads.splice(1,0,structuredClone(pad));assert(validState(state));assert(validState(DEFAULT_STATE));const sets=readSets(saveSet([],'riff','一首歌',state));const loaded=restoreArrangement(state,JSON.parse(JSON.stringify(sets[0].arrangement)));assert.deepEqual(loaded.pads[1],pad);loaded.pads[1].riff.steps[0].fret=5;assert.equal(sets[0].arrangement.pads[1].riff.steps[0].fret,3);const voice=padVoice(pad);voice.riff.steps[0].fret=9;assert.equal(pad.riff.steps[0].fret,3);
 const broken=structuredClone(state);broken.pads[1].riff.steps=[];assert.equal(validState(broken),false);
});
test('distinct same-named Riffs have separate prepared buffers pinned alongside chords',async()=>{
 const a=new GuitarAudio();a.renderChord=async()=>({duration:1});const other=structuredClone(pad);other.riff.steps[0].fret=5;await a.preparePads([{chord:'C',pattern:null},pad,other],DEFAULT_PATTERN);assert.equal(a.cache.size,3);assert(a.pinnedKeys.has(a.key(padVoice(pad),DEFAULT_PATTERN)));assert(a.pinnedKeys.has(a.key(padVoice(other),DEFAULT_PATTERN)));
});
