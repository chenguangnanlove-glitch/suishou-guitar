from pathlib import Path
html=Path('dist/index.html').read_text()
probe='''<script>
window.probeEvents=[];
function probeLog(kind,data){window.probeEvents.push({kind,time:Math.round(performance.now()*1000)/1000,...data});const out=document.getElementById('probeOutput');if(out)out.textContent=JSON.stringify(window.probeEvents.slice(-20),null,2);}
Object.defineProperty(navigator,'vibrate',{configurable:true,value:pattern=>{probeLog('vibrate',{pattern});return true;}});
const nativeStart=AudioBufferSourceNode.prototype.start;
AudioBufferSourceNode.prototype.start=function(...args){if(this.context instanceof AudioContext)probeLog('audio.start',{scheduled:args[0],current:this.context.currentTime});return nativeStart.apply(this,args);};
for(const kind of ['pointerdown','pointerup','click'])document.addEventListener(kind,e=>{const b=e.target.closest('button');if(b&&(b.classList.contains('pad')||b.id==='hapticTest'))probeLog(kind,{target:b.id||b.querySelector('strong')?.textContent,detail:e.detail,pointerType:e.pointerType});},true);
</script>'''
html=html.replace('</head>',probe+'</head>').replace('<main class="instrument">','<aside style="position:fixed;left:5px;top:5px;width:360px;max-height:90vh;overflow:auto;background:#fff;color:#000;z-index:999;font:11px monospace"><b>Local event probe — vibration API spy, no physical motor measurement</b><pre id="probeOutput"></pre></aside><main class="instrument">')
Path('dist/haptics-qa.html').write_text(html)
