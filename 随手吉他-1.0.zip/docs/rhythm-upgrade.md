# Right-hand rhythm cards (revision 18)

The preparation page now offers built-in and personal right-hand cards, per-pad entry points, and whole-group or multi-pad assignment. Song snapshots include up to six prepared cards. Personal library changes never automatically update saved arrangements.

Performance mode pins every prepared card × chord buffer before opening. Selecting a card only changes the pattern for the next chord press and does not start, interrupt, or re-render the playing pads. “按编排” restores each pad's arrangement settings. Riff timing remains independent.

Each custom strum/picking step carries a duration in sixteenth-note ticks (1, 2 or 4), with up to 32 steps / eight quarter-note beats. Picking steps support simultaneous strings and rests. Legacy uniform sequences remain playable and can be converted in the editor. Each chord press plays its phrase once.

Validation: 50 Node tests passed. Browser checks covered preset editing, mixed durations, personal saves, whole-group/batch/prepare-only assignment, arrangement reload, and 390×844, 360×740, 844×390 layouts with eight pads. Portrait/landscape performance rails measured 52/42px. Real-sample OfflineAudioContext stress test: 160 switches, zero missed plays, zero clipped samples, zero residual after stop, peak 0.249111, at most two overlapping fade voices. This verifies generated audio and browser interaction, not physical Android touch/audio latency.

Reproduce browser checks by copying tests/phone-shell.html and tests/rhythm-audio.html to the static directory temporarily, then opening them in the managed preview. Remove temporary QA pages before packaging.

## Revision 19: intrinsic-width regression

Reproduced the reported right-side clipping on a 360px viewport by switching to “下下上 · 十六分” without pressing another chord. The footer's longer pending-pattern label increased the implicit CSS grid column from 324px to 350.375px; the pads' right edge moved past the viewport to 368.375px.

The stage now explicitly uses minmax(0, 1fr) for its column. Direct children have bounded widths, and the footer's current-status flex item has a zero basis and clips text inside its allocation. The rhythm rail retains its own horizontal scroll.

Browser regression checks: at 360px, pad width remains 155.5px before and after switching, and pads/fullscreen/stop all end at x=342. At 390px, the right edge remains x=372; at 844px landscape, x=826. Stage horizontal overflow is false in all checked sizes. Eight-pad landscape grid ends at y=332, before the footer at y=338. No audio or arrangement code changed.

## Revision 20: precise tempo and discoverable removal

Right-hand cards now offer direct integer BPM entry (45–320), ±1 and ±5 buttons, and 60/80/100/120/160 presets. The slider remains for coarse adjustments; all controls share the same draft value. Blank input retains the previous tempo and out-of-range committed input is clamped.

Song and personal-library lists use labeled “移除” / “删除” buttons. Opening an existing card also shows its removal action at the top of the editor. Removal returns to the library with an undo action for the most recent removal during this session. Undo restores the saved snapshot, rather than any uncommitted edits in the editor. Removing from a song preserves its pads' existing playback settings; personal-library removal does not change song snapshots.

Browser checks: entered 97 BPM, exercised ±1/±5, checked 45/320 bounds and presets, saved/reopened at 97 BPM, removed/restored song and personal cards through editor/list entry points, and confirmed deletion persisted after reload. Undo restored 97 BPM even when the discarded editor draft had 111/115 BPM. A 360px phone frame showed no horizontal overflow in the new tempo controls. All 50 existing Node tests passed. Browser screenshot capture timed out; interactions and rendered DOM state were verified.
