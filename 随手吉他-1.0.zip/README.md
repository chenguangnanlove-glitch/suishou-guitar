# 随手吉他 — 声音样机

Buildless mobile web instrument. Serve `dist/` over HTTP(S). No package install/build or external runtime CDN needed.

- Four editable chord pads; pointerdown starts the bound articulation immediately after samples are ready.
- Global pattern plus per-pad overrides; down/up strum, arpeggio, custom string sequence, custom strum sequence, muted articulation.
- 27 acoustic guitar recording samples (5.7 MB). See `dist/audio/CREDITS.txt` for attribution and license.
- Web Audio buffers are preloaded/decoded. One-shot patterns, no tempo quantization or automatic loop. New gestures cancel pending notes, release older voices.
- Settings are saved in browser localStorage; no backend and no accounts inside the application.
- Touch response and sound on the user's physical Android device remain unverified. Bluetooth can add latency. First load needs network; offline reload is not guaranteed.
- Single velocity sample layer; variation is gain only, not round robin sample recordings. Slap is a muted approximation. No claim of professional sample-library fidelity.

## Verification
`node --test tests/*.test.js`
8 tests cover chord pitch classes, scheduling, muted strings, saved-state validation and cancellation/resume races. Browser QA covered rendering at 390 x 844, chord controls, global/per-pad editing, audition and persistence after reload. Audio files decoded in-browser; actual speaker output not objectively measured.

## Revision 2
- Removed normalized noise-based convolution; sparse early reflections, lower mix bus headroom and softer release tails. New configurations default to dry sound; existing settings remain compatible.
- Pinch mode triggers chosen strings at one exact timestamp. Bass follows chord, duplicate bass/string selections deduplicate. Custom picking supports simultaneous groups and rests.
- Touch step editor with direct middle-step editing, insertion, duplication, deletion and presets. BPM 45–320 with 1/2/4/8 subdivisions; arpeggio spacing retains its 0.62 factor.
- 11 Node tests pass, including exact simultaneous scheduling, grouped picking/rest timing, fast tempo and saved-state compatibility. Physical Android listening remains required to judge residual sample/device noise.

## Revision 3
27 samples receive conservative FFmpeg spectral noise reduction (8 dB), 45 Hz high-pass and 6.5 kHz low-pass. Same-string retriggers smoothly release the prior recording instead of layering its tail. Audio scheduling uses 6 ms lookahead and 4 ms attack ramp.
Home-screen opt-in haptic feedback uses one 10 ms vibration per accepted chord press. Preference persists locally. Unsupported/blocked vibration never prevents sound. Android hardware output and motor feel still need user listening/touch verification.
13 unit tests pass, including same-string release and haptic unsupported/error handling.

## Revision 4 — rapid chord switching
- Haptic dispatch now precedes all audio scheduling in the pointerdown path; no timer or pointerup dependency. Actual motor/speaker alignment depends on Android/browser hardware.
- Explicit portable gain envelopes replace cancelAndHoldAtTime. Release ramps reach exactly zero before sources stop. Repeated presses cannot extend an existing release. Future same-string scheduling keeps references until actual completion so all pending notes can be cancelled on a chord switch.
- Lower overlap headroom, 45 Hz bus high-pass, stronger peak compression and a smooth output guard; room reflections reduced.
- 19 unit tests passed. Real Chromium OfflineAudioContext stress rendering with the shipped samples passed 240 chord switches at 40 ms intervals, 160 presses at 8 ms intervals, and 48 interruptions of twelve-step fast strums. All had zero full-scale clipped samples, finite output, and zero output 400 ms after final stop. Peak magnitudes: 0.463448, 0.132820, 0.461833 respectively. These are signal checks, not proof of noise-free playback on the user's Android device.
- Reproduce offline QA by copying tests/offline-audio.html to dist/audio-qa.html, opening it via the normal preview and pressing Run; remove the copy before publishing.

## Revision 5 — prepared articulation playback
The supplied Android recording contains repeated brief high-frequency transients without full-scale clipping (recording peak 0.2746), so clipping-only validation cannot establish that the user's noise is fixed. The recording shows the haptic toggle unchecked; actual haptic delay cannot be measured from it.

The live path now plays one prepared stereo AudioBuffer per touch, instead of constructing/cancelling a separate graph for every string. Articulations are rendered in OfflineAudioContext when samples load or settings are saved/previewed. Live switching uses a single 16 ms gain fade with no envelope cancellation. Completed buffers start/end at exact silence and have a 0.42 peak ceiling; live output has a smooth peak guard. A bounded LRU cache pins current pad buffers; concurrent identical preparation deduplicates. Settings show preparation progress and prevent edits during preparation. A visible Revision 05 badge makes stale-client reports distinguishable.

22 unit tests pass. Actual Chromium browser checks covered loading, one-buffer playback, audition, saving and subsequent pad playback. Offline rendered tests passed 240 down-strum switches, 160 very fast grouped touches, and 48 interrupted twelve-step strum sequences. All produced finite output with no full-scale clipped samples and zero residual after final stop. Maximum live scheduled voices were 2, 4 and 2; output peaks 0.085457, 0.003317 and 0.349799 respectively. These results do not prove noise-free playback on the physical Android device.

## Revision 6 — haptic request diagnostics
The user confirmed sound is acceptable; audio synthesis, playback and sample assets are unchanged in this revision. Haptic pulse duration is selectable at 15/35/60 ms (35 ms default, replacing 10 ms); settings persist and old saved state remains valid. Off and backgrounding cancel pending web vibration. A separate [70,90,70] ms double-pulse test distinguishes requested web patterns from system touch feedback. UI describes request acknowledgement without claiming physical motor output. Vibration API limitations apply; actual Android motor latency and amplitude cannot be verified remotely.
23 Node tests pass. Browser QA covered double-test acknowledgement, duration selection, off/cancel messaging, persistence after reload and subsequent chord playback. W3C Vibration API: https://www.w3.org/TR/vibration/ (a true return does not prove physical vibration).

## Revision 7 — one distinct press pulse
User selected the 35 ms middle setting. All chord presses and the test button now request a single 35 ms pulse; the double-test pattern and duration selector are removed. Pointer clicks are excluded from the keyboard activation fallback to avoid duplicate touch dispatch. Existing saved vibration on/off preferences persist. Audio synthesis/playback/assets remain unchanged. 23 tests pass including single-pulse test parity, off cancellation and dispatch-before-audio.

## Revision 8 — actual browser event timing test
The second supplied recording shows vibration enabled and later disabled, but a screen recording cannot measure motor sensation. Its audio peak is 0.352, with zero full-scale clipped samples. A browser integration probe wrapped navigator.vibrate with a spy and logged trusted native pointer events and live AudioBufferSourceNode.start calls. This measures dispatch timing on the desktop test browser, not physical Android motor latency.

A real bug was reproduced: holding the haptic-test button for ~1 second delayed the request until pointerup/click (~1008 ms after pointerdown). The button now dispatches on pointerdown and its click handler handles only non-pointer keyboard activation, matching chord pads. After correction, a held test press dispatched one 35 ms request ~0.5 ms after pointerdown, with no request on release; warmed chord presses dispatched one request ~0.1–0.4 ms after pointerdown and scheduled audio afterward. First audio context resume took ~57 ms in the test browser, separate from haptic command timing. No claim of physical motor synchronization follows from these values.

Reproduce with `python tests/haptics-browser-probe.py`, serve the normal preview, open `/haptics-qa.html`, hold the test button then chord pads, and inspect the on-page log. Remove dist/haptics-qa.html before publishing. The probe intentionally spies the API and does not vibrate hardware.

## Revision 9 — direct chord selection
- Each performance pad has a separate Change button. The new chooser provides large chord cards, search (including Unicode accidentals and enharmonic aliases), common/major/minor/seventh/suspended categories, recent selections, audition and explicit commit. It prepares a replacement before updating the pad and retains per-pad articulation overrides.
- Added 84 verified voicings across twelve chromatic roots × major/minor/dominant7/major7/minor7/sus2/sus4. The original eighteen open-position voicings are preserved exactly; remaining voicings use movable E/A guitar shapes. Audio algorithms and sample files are unchanged; only module cache versions are updated so the expanded chord bank is used throughout.
- Performance pads can be added up to eight and removed down to two, with a compact mobile layout for more than four. Existing four-pad saved configurations remain compatible. Vibration remains an optional toggle with the established single 35 ms pulse.
- 27 unit tests pass, including independent pitch-class verification of every voicing, search ambiguity/enharmonic aliases, and two-to-eight pad validation. Browser QA used a 390×844 iframe viewport and verified Bbm replacement from an A#m query, audition, retaining the prior independent arpeggio, adding to eight, disabling Add at the limit, removing a pad, recent history, seven-pad restoration and playback after reload, and new-pad settings scope. No horizontal overflow was measured (body clientWidth=scrollWidth=375 with the native scrollbar). The chooser has a single scrolling card grid with visible footer actions.

## Revision 10 — visual redesign and custom fretboard chords
The interface now uses a warm paper background, blue selected pads, quieter hierarchy, clearer cards and a collapsible optional haptics section. The chooser has Library and Custom Fretboard tabs. The fingerboard shows strings 1–6 (thin to thick), muted/open controls and paged fret ranges 1–4, 5–8 and 9–12. Each string has one selected position; pitch names and the resulting octave-specific notes update with selection. Matching chord names are suggestions, not mandatory identities. Users can name and audition any non-empty combination and save it as a performance pad.

Custom pads persist their exact six fret values independently of their label. Audio preparation, cache pinning, pad playback, settings audition and right-hand overrides all use those stored frets; choosing a library chord explicitly removes the custom voicing. Empty or malformed voicings are rejected and custom labels render as text. Old saved states remain compatible.

30 tests pass, including exact custom MIDI pitches, fret/name state roundtrip, invalid/empty rejection, and cache separation of different same-named voicings. Browser QA at a 390×844 viewport built a non-library voicing, named it, auditioned/saved it as an eighth pad, restored its exact positions after reload, assigned an independent arpeggio and played it, then selected/previewed/saved fret 12 and confirmed restoration at E5. Muting every string disabled Save. The body and dialog measured 375 px with no horizontal overflow. Optional haptics remain available inside Touch Feedback.

## Revision 11 — spacious chooser and sliding fingerboard
The mobile chooser fills the viewport, removes repeated helper/header text, uses larger three-column library cards and a single horizontal category row. Optional custom naming and note details are collapsed by default. Footer audition/commit actions remain visible.
The fingerboard now renders all fret positions 0–12 in one horizontally scrollable surface; string labels, mute controls and open-string positions remain sticky. Native touch panning and scrollbar navigation are enabled, and the horizontal offset is explicitly preserved while note selection rerenders. The old three-page fret controls are removed.
30 unit tests remain passing. Browser checks at 390×844 verified native horizontal scrolling (scrollLeft 200), selection at that offset without jumping, selection at fret 12 (scrollLeft retained at 464), audition and save, and the roomier library view. Audio and stored custom fret semantics are unchanged.

## Revision 12 — mobile fingerboard and reliable chord names
Reproduced the reported mismatch: changing a saved custom C voicing to F retained the old automatically filled C label while playing the correct F notes. Automatic and manual names now have separate metadata; automatic labels follow the selected pitch classes. Legacy library-style labels are repaired from their stored frets, preserving the exact voicing and free-form custom names. Explicit manual names remain available with a warning when a known chord name conflicts with the selection.

The mobile fingerboard uses 64×56 px note targets and one 52 px fixed string control instead of three fixed columns. String controls toggle mute/restore; tapping a selected note again cancels it. Selection updates existing elements without rebuilding the board, preserving scroll position. Pointer movement and scroll guards prevent panning from selecting notes. Naming and reset tools remain in optional details.

34 unit tests pass, including migration, manual naming, pitch integrity and gesture guards. Browser checks at a 390×844 viewport reproduced the old bug, verified automatic repair, C-to-F and F-to-C naming, selected-note cancellation, horizontal panning without note changes, manual-name conflict messaging, audition, save, reload and subsequent playback. Audio synthesis and sample assets are unchanged.

## Revision 13 — saved sets and a separate performance page
The arrangement page retains editing and audition. Named local sets save the entire pad order, exact custom frets, automatic/manual labels, shared right-hand pattern and per-pad overrides. Save replaces the selected set; Save As creates another. Loading prepares all sounds before swapping the arrangement and retains device volume/haptic preferences. Unsaved changes receive a replacement prompt; deleting a saved record retains the current draft so it can be saved again. Existing local drafts are preserved and no set is invented automatically.

The dedicated #play page snapshots the current arrangement on entry. It has no editing controls, does not rerender buttons on touch, and keeps pad positions fixed during playing. A quiet dark surface contains large pads, current chord, stop, return to arrangement and optional fullscreen. Portrait uses two columns; landscape uses one row for two to four chords, three columns for five/six and four columns for seven/eight. Native rotation determines the viewport; fullscreen is optional and has a fallback message. Returning, page hiding and browser navigation stop sound.

38 unit tests pass, including save isolation, exact custom voicing/pattern restoration, targeted overwrite/deletion, damaged-record filtering and preference preservation. Browser QA covered saving, copying, overwriting, independent A/B loading, unsaved-change prompts, deleting B while retaining its draft, and persisted sets after reload. Performance QA covered 390×844 portrait, 844×390 landscape (four and eight pads), 667×375 landscape (eight pads), chord playback, stop, fullscreen toggle, return to editing, direct #play opening and reload. Tested landscape views had no scroll overflow. Audio synthesis, preparation algorithms and samples are unchanged.

## Revision 14 — modern Material interface and app-owned choice sheets
Rebuilt the accumulated stylesheet into a coherent mobile Material-inspired design system: cool light canvas, green tonal controls, four quiet pad colors, consistent type/spacing, pill actions, soft sheets, custom range/switch styling and matching dark performance surfaces. The editor uses a compact group summary instead of a permanently exposed naming form. Saving and Save As open a dedicated naming sheet with chord previews; cancellation restores the prior name and Enter commits explicitly.

All native select popups now have accessible app-owned choice sheets, including saved sets, setting scope, articulation, subdivision and chord fields. Saved sets show their chord contents; current draft previews follow the actual edited arrangement. The underlying select models remain for existing validation and setting handlers. Choice commits dispatch both input and change so articulation edits and scope changes keep working. Current selection, disabled state, keyboard focus and long scrolling lists are handled. Existing local storage and audio preparation/playback remain intact.

38 unit tests remain passing. Real browser QA covered the 390 px and 360 px phone editor, save/rename, Save As via Enter, group loading, cancellation restoring the prior name, nested articulation choice to simultaneous plucking, audition, settings commit, custom fingerboard, and four/eight-pad 844×390 performance playback/stop. Editor and landscape performance widths matched their scroll widths, and no native select remained visible. The mobile viewport requests content resizing for the on-screen keyboard where supported. No audio synthesis or sample changes.

## Revision 15 — visible custom chord naming and fewer articulations
Custom fingerboard naming is now directly above the board rather than hidden in optional details. Blank names still use pitch-based automatic identification; typed names retain their manual identity and exact frets across saving, reload and performance. Chinese characters count as wide characters for pad label sizing, with smaller long-name typography and space reserved below edit controls.

The standalone short-muted-strum option is removed from articulation selection. Existing drafts and saved sets migrate that retired style to down-strum while retaining fret positions, manual names, independent overrides and the remaining pattern parameters. Custom strum sequencing is otherwise unchanged.

39 tests pass, including migration of both shared and independent retired patterns, saved-set restoration, exact voicing preservation and wide-character label sizing. Browser QA at 360×800 verified the name input is immediately visible outside details, saving/reopening/reloading a Chinese name, a four-character pad label with no overlap with its edit control, named-pad performance playback, and the six remaining articulation choices.

## Revision 16 — simple Riff performance keys
Added a standalone mobile Riff editor: tap the continuous guitar fingerboard to append single notes with immediate audition, select a step to replace it, delete the selected step, append/replace rests, set one shared speed and name the result. Sequences contain 1–16 equal eighth-note steps at 60–320 BPM; all-rest/empty sequences cannot be saved. Step and fretboard scrolling remain stable during note entry. No looping, per-note rhythm, recording or multi-note steps are introduced.

Riff pads share the two-to-eight-key arrangement with chords, show a Riff/step-count marker, have a dedicated edit/remove flow and roundtrip in existing local set storage. Chord settings skip Riff keys without losing original pad indexes. Saved Riff speed remains independent of chord articulation tempo. Performance uses the same pre-rendered one-buffer playback, bounded cache, pinning and 16 ms live crossfade as chords; repeats restart the Riff, another pad interrupts it and Stop cancels it. Existing guitar sample assets and chord envelopes remain unchanged. Only Riff note events use a short gated envelope to make rests and successive melody notes clear.

44 Node tests pass, covering exact MIDI/string order, rest timing, equal-step gates, limits and invalid input, immutable append/replace, mixed-state/set roundtrip and distinct same-named Riff cache entries. Browser QA covered 390×844 note entry/audition, rest, replacement, deletion, sixteen-step rejection with replacement still allowed, fret 12 at scrollLeft 576, cancel preserving the prior three-note Riff, save/edit/reload, mixed-set save/load, chord editing after a Riff slot and 844×390 performance switching with no overflow.

Real Chromium OfflineAudioContext validation using shipped guitar samples passed 160 Riff/chord switches at 40 ms intervals: finite output, peak 0.314419, zero full-scale clipped samples, zero signal in the tested rest window and zero residual 400 ms after final stop; maximum scheduled live voices 2. These are signal checks, not a physical Android noise/latency measurement. Reproduce by copying tests/riff-audio.html to dist/riff-audio-qa.html, using the normal preview and pressing Run; remove the temporary copy before publication.

## Revision 17 — compact arrangement homepage
The homepage retains the existing blue/green/sand/lavender pad colors while making arrangement keys compact. Removed the large heading and repeated introductory copy. The group selector, save and overflow actions now share a compact panel; Save As and Delete remain accessible in the overflow sheet. The sample status and audition status are quiet single-line rows. Stop and Enter Performance are fixed in a bottom action bar with safe-area spacing. Volume, optional haptics and usage information are grouped inside the existing settings sheet. Saving an articulation retains the current device volume and haptic preference.

All new pad sizing is scoped to #editorPage. The performance page keeps its existing large pads, audio behavior and landscape layout. Chord and Riff edit controls remain directly accessible, with no additional editing mode. Existing local data and sample assets are unchanged.

44 unit tests pass. Browser checks covered the 390×844 editor, eight-key 360×740 editor (92 px key height, final grid bottom 641 versus action-bar top 663, no horizontal overflow), chord/Riff audition, direct Riff editing, Save As via the overflow sheet, relocated volume controls retaining their value after saving articulation, entering performance and eight-key 844×390 playback/stop with no overflow. Audio modules and samples are unchanged.
